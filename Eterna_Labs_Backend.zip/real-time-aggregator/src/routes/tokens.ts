﻿import express from "express";
import { createCache } from "../cache";
import { Aggregator } from "../aggregator";

const router = express.Router();
let aggregator: Aggregator | null = null;

router.get("/", async (_req, res) => {
  try {
    console.log("⚡ /tokens request received");
    if (!aggregator) {
      console.log("🧠 Initializing aggregator...");
      const cache = await createCache();
      aggregator = new Aggregator(cache);
      await aggregator.init();
    }
    const data = aggregator.getAll();
    console.log(`✅ Returning ${data.length} tokens`);
    res.json({ data });
  } catch (err) {
    console.error("❌ Error in /tokens route:", err);
    res.status(500).json({ error: "internal_error" });
  }
});

export default router;
