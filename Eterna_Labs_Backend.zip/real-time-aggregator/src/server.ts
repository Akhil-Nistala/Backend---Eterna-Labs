﻿import http from "http";
import app from "./app";
import { Aggregator } from "./aggregator";
import { createCache } from "./cache";
import { initWebsocket } from "./websocket";

export async function startServer() {
  const port = Number(process.env.PORT || 4000);
  const server = http.createServer(app);
  const cache = await createCache();
  const aggregator = new Aggregator(cache);
  initWebsocket(server, aggregator);
  server.listen(port, () =>
    console.log(`✅ Server running at http://localhost:${port}`),
  );
}
