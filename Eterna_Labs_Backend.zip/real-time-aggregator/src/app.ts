﻿import express from "express";
import cors from "cors";
import tokens from "./routes/tokens";
const app = express();
app.use(cors());
app.use(express.json());
app.use("/tokens", tokens);
app.get("/", (_req, res) =>
  res.json({ ok: true, service: "real-time-aggregator" }),
);
export default app;
