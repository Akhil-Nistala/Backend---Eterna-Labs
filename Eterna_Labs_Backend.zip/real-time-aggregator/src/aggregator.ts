﻿import axios from "axios";

export class Aggregator {
  private cache: any;
  private tokens: any[] = [];

  constructor(cache: any) {
    this.cache = cache;
  }

  async fetchFromDexScreener(query: string) {
    try {
      console.log("🔄 Fetching from DexScreener...");
      const res = await axios.get(
        `https://api.dexscreener.com/latest/dex/search?q=${query}`,
      );
      return (
        res.data.pairs?.map((p: any) => ({
          symbol: p.baseToken.symbol,
          address: p.baseToken.address,
          priceUsd: parseFloat(p.priceUsd),
          source: "DexScreener",
          lastUpdated: Date.now(),
        })) || []
      );
    } catch (err: any) {
      console.error("❌ DexScreener fetch error:", err.message);
      return [];
    }
  }

  async fetchFromJupiter(query: string) {
    try {
      console.log("🔄 Fetching from Jupiter...");
      const res = await axios.get(`https://price.jup.ag/v4/price?ids=${query}`);
      const data = res.data?.data || {};

      const results = Object.keys(data).map((symbol) => ({
        symbol,
        priceUsd: data[symbol].price ?? 0,
        source: "Jupiter",
        lastUpdated: Date.now(),
      }));

      console.log(`✅ Jupiter response received: ${results.length} tokens`);
      return results;
    } catch (err: any) {
      console.error("❌ Jupiter fetch error:", err.message);
      return [];
    }
  }

  async fetchFromGecko(query: string) {
    try {
      console.log("🔄 Fetching from CoinGecko...");
      const res = await axios.get(
        `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=solana`,
      );
      return res.data.map((coin: any) => ({
        symbol: coin.symbol.toUpperCase(),
        address: coin.id,
        priceUsd: coin.current_price,
        source: "GeckoTerminal",
        lastUpdated: Date.now(),
      }));
    } catch (err: any) {
      console.error("❌ CoinGecko fetch error:", err.message);
      return [];
    }
  }

  async init() {
    console.log("⚙️ Initializing aggregator...");
    const dexData = await this.fetchFromDexScreener("SOL");
    const jupData = await this.fetchFromJupiter("SOL");
    const geckoData = await this.fetchFromGecko("SOL");

    this.tokens = [...dexData, ...jupData, ...geckoData];
    console.log(`✅ Aggregated ${this.tokens.length} tokens total`);
  }

  getAll() {
    return this.tokens;
  }
}
