﻿import axios from "axios";
import { Token } from "../types";
export async function fetchDex(query: string): Promise<Token[]> {
  try {
    const r = await axios.get(
      `https://api.dexscreener.com/latest/dex/search?q=${encodeURIComponent(query)}`,
      { timeout: 8000 },
    );
    return (r.data?.pairs || []).map((p: any) => ({
      token_address: p.baseToken?.address || p.pairAddress,
      token_name: p.baseToken?.name,
      token_ticker: p.baseToken?.symbol,
      price_sol: +p.priceUsd || 0,
      volume_sol: +p.volumeUsd24h || 0,
      market_cap_sol: +p.fdv || 0,
      source: "dexscreener",
      last_updated: Date.now(),
    }));
  } catch {
    return [];
  }
}
