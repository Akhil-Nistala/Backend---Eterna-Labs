﻿import axios from "axios";
import { Token } from "../types";
export async function fetchJupiter(query: string): Promise<Token[]> {
  try {
    const r = await axios.get(
      `https://lite-api.jup.ag/tokens/v2/search?query=${encodeURIComponent(query)}`,
      { timeout: 8000 },
    );
    return (r.data?.data || []).map((t: any) => ({
      token_address: t.address,
      token_name: t.name,
      token_ticker: t.symbol,
      price_sol: +t.price || 0,
      volume_sol: +t.volume || 0,
      market_cap_sol: +t.marketCap || 0,
      source: "jupiter",
      last_updated: Date.now(),
    }));
  } catch {
    return [];
  }
}
