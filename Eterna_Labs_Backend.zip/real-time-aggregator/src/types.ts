﻿export type Token = {
  token_address: string;
  token_name?: string;
  token_ticker?: string;
  price_sol?: number;
  volume_sol?: number;
  market_cap_sol?: number;
  source?: string;
  last_updated?: number;
};
