﻿import { Server as HttpServer } from "http";
import { Server as IOServer } from "socket.io";
import { Aggregator } from "./aggregator";
export function initWebsocket(s: HttpServer, a: Aggregator) {
  const io = new IOServer(s, { cors: { origin: "*" } });
  io.on("connection", (sock) => {
    console.log("socket connected", sock.id);
    sock.emit("initial", a.getAll().slice(0, 20));
    const int = setInterval(
      () => sock.emit("update", a.getAll().slice(0, 20)),
      15000,
    );
    sock.on("disconnect", () => clearInterval(int));
  });
}
