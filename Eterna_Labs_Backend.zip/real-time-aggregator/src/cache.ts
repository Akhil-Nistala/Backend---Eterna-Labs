﻿import Redis from "ioredis";

export async function createCache() {
  try {
    const redis = new Redis({
      host: "127.0.0.1",
      port: 6379,
      connectTimeout: 1000,
      retryStrategy: () => null,
    });

    await redis.ping();
    console.log("✅ Connected to Redis cache");
    return redis;
  } catch (err) {
    console.log("⚠️ Redis not available, using in-memory cache");

    const memoryCache = new Map<string, any>();
    return {
      async get(key: string) {
        return memoryCache.get(key);
      },
      async set(key: string, val: any) {
        memoryCache.set(key, val);
      },
      async del(key: string) {
        memoryCache.delete(key);
      },
    };
  }
}
